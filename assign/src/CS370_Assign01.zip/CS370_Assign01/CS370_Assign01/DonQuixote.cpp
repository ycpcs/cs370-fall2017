// CS370 - Fall 2016
// Assign01 - DonQuixote

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glut.h>
#endif
#include <math.h>
#include <stdlib.h>

#define DEG2RAD 0.017453

// Instance square - DO NOT MODIFY
GLfloat sqr[4][2] = {{1.0f,1.0f},{-1.0f,1.0f},{-1.0f,-1.0f},{1.0f,-1.0f}};

// Grass global variables

// Sky global variables

// Sun global variables

// House global variables

// Fan global variables

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();

int main(int argc, char* argv[])
{

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();
		
	// Flush buffer
	glFlush();
	
	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{

}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// Quit with escape
	if(key == 27)
	{
		exit(0);
	}
}

// Idle callback
void idlefunc()
{

}
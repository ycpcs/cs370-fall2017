// CS370 - Fall 2016
// Lab14 - RecursiveCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"
#include "vectorops.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint numLights_param;
GLint numLights = 2;

#define CUBE 1
#define X 0
#define Y 1
#define Z 2

bool anim = false;

// Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// Light0 (broad spot) Parameters
GLfloat light0_pos[] = {0.0f,0.0f,2.0f,1.0f};
GLfloat light0_dir[] = {0.0f,0.0f,-1.0f};
GLfloat light0_cutoff = 50.0f;
GLfloat light0_exp = 0.0f;

// Light1 (narrow spot) Parameters
GLfloat light1_pos[] = {0.0f,3.0f,0.0f,1.0f};
GLfloat light1_dir[] = {0.0f,-1.0f,0.0f};
GLfloat light1_cutoff = 20.0f;
GLfloat light1_exp = 0.0f;

// Global rotation angle
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global subdivision parameters
int div_level = 3;

// Global camera vectors
GLfloat eye[3] = {1.0f,1.0f,1.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global screen dimensions
GLfloat ww,hh;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void colorcube();
void rquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[]);
void div_quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], int n);
void create_lists();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Recursive Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Create display list
	create_lists();

	// TODO: Set ambient light
	GLfloat background[4] = { 1.0f,1.0f,1.0f,1.0f };
	set_AmbientLight(background);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	numLights_param = glGetUniformLocation(shaderProg,"numLights");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-3.0f*xratio, 3.0f*xratio, -3.0f*yratio, 3.0f*yratio, -3.0f, 3.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Activate shader program
	glUseProgram(shaderProg);
	// Set number of lights
	glUniform1i(numLights_param,numLights);

	// TODO: Turn on light0 (broad spot)
	set_SpotLight(GL_LIGHT0, &white_light, light0_pos, light0_dir, light0_cutoff, light0_exp);

	// TODO: Turn on light1 (narrow spot)
	set_SpotLight(GL_LIGHT1, &blue_light, light1_pos, light1_dir, light1_cutoff, light1_exp);

	// Render cube using display list
	glPushMatrix();
		set_material(GL_FRONT_AND_BACK, &brass);
		glTranslatef(0.0f, 0.0f, 0.0f);
		glRotatef(theta,0.0f,1.0f,0.0f);
		glScalef(1.0f, 1.0f, 1.0f);
		glCallList(CUBE);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// < > change subdivision level
	if (key == '<' || key == ',')
	{
		div_level--;
		if (div_level < 0)
		{
			div_level = 0;
		}
		// Recursive level changed, recreate list
		create_lists();
	}
	else if (key == '>' || key == '.')
	{
		div_level++;
		// Recursive level changed, recreate list
		create_lists();
	}

	// <space> toggles animation
	if (key == ' ')
	{
		anim = !anim;
	}	
	
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Routine to draw cube
void colorcube()
{
	// Top face
	div_quad(cube[4], cube[7], cube[6], cube[5], div_level);

	// Bottom face
	div_quad(cube[0], cube[1], cube[2], cube[3], div_level);

	// Left face
	div_quad(cube[0], cube[3], cube[7], cube[4], div_level);

	// Right face
	div_quad(cube[1], cube[5], cube[6], cube[2], div_level);

	// Front face
	div_quad(cube[2], cube[6], cube[7], cube[3], div_level);

	// Back face
	div_quad(cube[0], cube[4], cube[5], cube[1], div_level);
}

// Routine to perform recursive subdivision
void div_quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], int n)
{
	GLfloat v1_prime[3],v2_prime[3],v3_prime[3],v4_prime[3],v5_prime[3];

	// Recurse until n = 0
	if (n > 0)
	{
		// TODO: Compute midpoints
		for (int i = 0; i<3; i++)
		{
			v1_prime[i] = (v4[i] + v1[i]) / 2.0f;
			v2_prime[i] = (v1[i] + v2[i]) / 2.0f;
			v3_prime[i] = (v2[i] + v3[i]) / 2.0f;
			v4_prime[i] = (v3[i] + v4[i]) / 2.0f;
			v5_prime[i] = (v1[i] + v2[i] + v3[i] + v4[i]) / 4.0f;
		}

		// TODO: Subdivide polygon
		div_quad(v1, v2_prime, v5_prime, v1_prime, n - 1);
		div_quad(v2_prime, v2, v3_prime, v5_prime, n - 1);
		div_quad(v1_prime, v5_prime, v4_prime, v4, n - 1);
		div_quad(v5_prime, v3_prime, v3, v4_prime, n - 1);
	}
	else
	{
		// TODO: Otherwise render quad
		rquad(v1, v2, v3, v4);
	}
}

// Routine to draw quadrilateral face
void rquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[])
{
	GLfloat normal[3];
	// TODO: Compute normal via cross product
	cross(v1, v2, v4, normal);
	normalize(normal);

	// TODO: Set normal
	glNormal3fv(normal);

	// Draw face 
	glBegin(GL_POLYGON);
			glVertex3fv(v1);
			glVertex3fv(v2);
			glVertex3fv(v3);
			glVertex3fv(v4);
	glEnd();
}

// Idle callback
void idlefunc()
{
	if (anim)
	{
		// Update rotation angle
		theta += dtheta;
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}

		glutPostRedisplay();
	}
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// Store new extents
	ww = w;
	hh = h;
}



// Routine to create display lists
void create_lists()
{
	// Create colorcube display list
	glNewList(CUBE, GL_COMPILE);
		glPushAttrib(GL_CURRENT_BIT);
		colorcube();
		glPopAttrib();
	glEndList();
}


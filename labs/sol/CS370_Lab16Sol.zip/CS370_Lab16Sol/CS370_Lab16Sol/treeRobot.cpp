// CS370 - Fall 2016
// Lab16 - TreeRobot

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* lightVertexFile = "lightvert.vs";
GLchar* lightFragmentFile = "lightfrag.fs";
GLchar* defaultVertexFile = "basicvert.vs";
GLchar* defaultFragmentFile = "basicfrag.fs";

// Shader objects
GLuint lightShaderProg;
GLuint defaultShaderProg;
GLuint numLights_param;

#define BRASS 1
#define RED_PLASTIC 2
#define X 0
#define Y 1
#define Z 2

// Node structure
struct treenode
{
	MaterialType material;
	GLfloat color[4];
	GLuint texture;
	void (*f)();
	GLfloat m[16];
	treenode *sibling;
	treenode *child;
	GLuint shaderProg;
};

// Define object dimensions
#define BASE_RADIUS 3.0f
#define BASE_HEIGHT 3.0f
#define LOWER_HEIGHT 4.0f
#define LOWER_WIDTH 2.0f
#define LOWER_DEPTH 1.0f
#define UPPER_HEIGHT 3.0f
#define UPPER_WIDTH 1.0f
#define UPPER_DEPTH 1.0f

// Scene nodes
treenode base;
treenode lower_arm;
treenode left_upper_arm;
treenode right_upper_arm;

// Rotation angles
GLfloat theta = 0.0f;
GLfloat dtheta = 1.0f;
GLfloat phi = 0.0f;
GLfloat dphi = 1.0f;
GLfloat left_psi = 0.0f;
GLfloat right_psi = 0.0f;
GLfloat dpsi = 1.0f;

// Light0 (directional) Parameters
GLfloat light0_pos[] = {0.0f,0.0f,5.0f,1.0f};
GLfloat light0_dir[] = {0.0f,0.0f,-1.0f};
GLfloat light0_cutoff = 45.0f;
GLfloat light0_exp = 0.0f;

// Global light variables
GLint numLights = 1;

// Global camera vectors
GLfloat eye[3] = {1.0f,1.0f,1.0f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global screen dimensions
GLfloat ww,hh;

// Quadric object
GLUquadricObj *basequad;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void build_scene_graph();
void traverse(treenode *node);
void update_base();
void update_lower_arm();
void update_left_upper_arm();
void update_right_upper_arm();
void draw_base();
void draw_lower_arm();
void draw_upper_arm();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Tree Robot");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);

	// Create base quadric object
	basequad = gluNewQuadric();
	gluQuadricDrawStyle(basequad,GLU_FILL);
	gluQuadricNormals(basequad,GLU_SMOOTH);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Set ambient light
	GLfloat background[] = {1.0f,1.0f,1.0f,1.0f};
	set_AmbientLight(background);

	// Load shader programs
	lightShaderProg = load_shaders(lightVertexFile,lightFragmentFile);
	defaultShaderProg = load_shaders(defaultVertexFile,defaultFragmentFile);

	// Associate num_lights parameter
	numLights_param = glGetUniformLocation(lightShaderProg,"numLights");

	// Build scene graph
	build_scene_graph();

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Adjust viewing volume (orthographic)
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// If taller than wide adjust y
	if (ww <= hh)
	{
		yratio = (GLfloat)hh / (GLfloat)ww;
	}
	// If wider than tall adjust x
	else if (hh <= ww)
	{
		xratio = (GLfloat)ww / (GLfloat)hh;
	}
	glOrtho(-10.0f*xratio, 10.0f*xratio, -10.0f*yratio, 10.0f*yratio, -10.0f, 10.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Turn on global light0 (broad spot)
	set_SpotLight(GL_LIGHT0, &blue_light, light0_pos, light0_dir, light0_cutoff, light0_exp);

	// TODO: Render scene graph
	traverse(&base);
}

void build_scene_graph()
{
	// TODO: Create base node
	base.material = brass;
	base.f = draw_base;
	base.sibling = NULL;
	base.child = &lower_arm;
	base.shaderProg = lightShaderProg;
	update_base();

	// TODO: Create lower arm node
	lower_arm.color[0] = 1.0f;
	lower_arm.color[1] = 0.0f;
	lower_arm.color[2] = 0.0f;
	lower_arm.color[3] = 1.0f;
	lower_arm.f = draw_lower_arm;
	lower_arm.sibling = NULL;
	lower_arm.child = &left_upper_arm;
	lower_arm.shaderProg = defaultShaderProg;
	update_lower_arm();

	// TODO: Create left upper arm node
	left_upper_arm.f = draw_upper_arm;
	left_upper_arm.sibling = &right_upper_arm;
	left_upper_arm.child = NULL;
	update_left_upper_arm();

	// TODO: Create right upper arm node
	right_upper_arm.f = draw_upper_arm;
	right_upper_arm.sibling = NULL;
	right_upper_arm.child = NULL;
	update_right_upper_arm();
}

// Routine to traverse scene graph
void traverse(treenode *node)
{
	// TODO: Add traversal code
	// Stop when at bottom of branch
	if (node == NULL)
	{
		return;
	}

	// Apply local transformation and render
	glPushMatrix();
	glMultMatrixf(node->m);
	glUseProgram(node->shaderProg);
	node->f();

	// Recurse vertically if possible (depth-first)
	if (node->child != NULL)
	{
		traverse(node->child);
	}

	// Remove local transformation and recurse horizontal
	glPopMatrix();
	if (node->sibling != NULL)
	{
		traverse(node->sibling);
	}
}

// Routine to update base transformation
void update_base()
{
	glPushMatrix();
		glLoadIdentity();
		// TODO: Rotate about y axis
		glRotatef(theta, 0.0f, 1.0f, 0.0f);

		// TODO: Retrieve transformation matrix
		glGetFloatv(GL_MODELVIEW_MATRIX, base.m);
	glPopMatrix();
}

// Routine to update lower arm transformation
void update_lower_arm()
{
	glPushMatrix();
		glLoadIdentity();
		// TODO: Move on top of base
		glTranslatef(0.0f, BASE_HEIGHT, 0.0f);

		// TODO: Rotate about x axis
		glRotatef(phi, 1.0f, 0.0f, 0.0f);

		// TODO: Retrieve transformation matrix
		glGetFloatv(GL_MODELVIEW_MATRIX, lower_arm.m);
	glPopMatrix();
}

// Routine to update left upper arm transformation
void update_left_upper_arm()
{
	glPushMatrix();
		glLoadIdentity();
		// TODO: Move to left side of lower arm
		glTranslatef((LOWER_WIDTH + UPPER_WIDTH) / 2.0f, LOWER_HEIGHT, 0.0f);

		// TODO: Rotate about x axis
		glRotatef(left_psi, 1.0f, 0.0f, 0.0f);

		// TODO: Retrieve transformation matrix
		glGetFloatv(GL_MODELVIEW_MATRIX, left_upper_arm.m);
	glPopMatrix();
}

// Routine to update right upper arm transformation
void update_right_upper_arm()
{
	glPushMatrix();
		glLoadIdentity();
		// TODO: Move to right side of lower arm
		glTranslatef(-(LOWER_WIDTH + UPPER_WIDTH) / 2.0f, LOWER_HEIGHT, 0.0f);

		// TODO: Rotate about x axis
		glRotatef(right_psi, 1.0f, 0.0f, 0.0f);

		// TODO: Retrieve transformation matrix
		glGetFloatv(GL_MODELVIEW_MATRIX, right_upper_arm.m);
	glPopMatrix();
}

// Routine to draw base
void draw_base()
{
	glPushMatrix();
		// Set uniform shader variable and material
		glUniform1i(numLights_param,numLights);
		set_material(GL_FRONT_AND_BACK,&base.material);
		// Rotate onto x-y plane
		glTranslatef(0.0f,0.0f,0.0f);
		glRotatef(-90.0f,1.0f,0.0f,0.0f);
		glScalef(1.0f,1.0f,1.0f);
		gluCylinder(basequad,BASE_RADIUS,BASE_RADIUS,BASE_HEIGHT,20,20);
	glPopMatrix();
}

// Routine to draw lower arm
void draw_lower_arm()
{
	glPushMatrix();
		glColor3fv(lower_arm.color);
		// Translate up to x-y plane
		glTranslatef(0.0f,LOWER_HEIGHT/2.0f,0.0f);
		glRotatef(0.0f,0.0f,0.0f,1.0f);
		glScalef(LOWER_WIDTH,LOWER_HEIGHT,LOWER_DEPTH);
		glutSolidCube(1.0f);
	glPopMatrix();
}

// Routine to draw upper arm
void draw_upper_arm()
{
	glPushMatrix();
		glColor3f(0.0f,0.0f,1.0f);
		// Translate up to x-y plane
		glTranslatef(0.0f,UPPER_HEIGHT/2.0f,0.0f);
		glRotatef(0.0f,0.0f,0.0f,1.0f);
		glScalef(UPPER_WIDTH,UPPER_HEIGHT,UPPER_DEPTH);
		glutSolidCube(1.0f);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// a d rotate base
	if (key == 'a')
	{
		theta += dtheta;
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}
		// TODO: Update base
		update_base();
	}
	else if (key == 'd')
	{
		theta -= dtheta;
		if (theta < 0.0f)
		{
			theta += 360.0f;
		}
		// TODO: Update base
		update_base();
	}

	// w s rotates lower arm
	if (key == 'w')
	{
		phi += dphi;
		if (phi > 90.0f)
		{
			phi = 90.0f;
		}
		// TODO: Update lower arm
		update_lower_arm();
	}
	else if (key == 's')
	{
		phi -= dphi;
		if (phi < -90.0f)
		{
			phi = -90.0f;
		}
		// TODO: Update lower arm
		update_lower_arm();
	}

	// m n rotates left upper arm
	if (key == 'm')
	{
		left_psi += dpsi;
		if (left_psi > 180.0f)
		{
			left_psi = 180.0f;
		}
		// TODO: Update left upper arm
		update_left_upper_arm();
	}
	else if (key == 'n')
	{
		left_psi -= dpsi;
		if (left_psi < -180.0f)
		{
			left_psi = -180.0f;
		}
		// TODO: Update left upper arm
		update_left_upper_arm();
	}

	// . , rotates right upper arm
	if (key == '.')
	{
		right_psi += dpsi;
		if (right_psi > 180.0f)
		{
			right_psi = 180.0f;
		}
		// TODO: Update right upper arm
		update_right_upper_arm();
	}
	else if (key == ',')
	{
		right_psi -= dpsi;
		if (right_psi < -180.0f)
		{
			right_psi = -180.0f;
		}
		// TODO: Update right upper arm
		update_right_upper_arm();
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// Store new extents
	ww = w;
	hh = h;
}

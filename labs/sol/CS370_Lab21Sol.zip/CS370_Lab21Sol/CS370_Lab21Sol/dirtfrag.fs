// TODO: Sampler variables
uniform sampler2D texMap;
uniform sampler2D dirtMap;

varying vec4 baseColor;

void main()
{  
	// TODO: Sample textures
	vec4 texColor = texture2D(texMap, gl_TexCoord[0].st);
	vec4 dirtColor = texture2D(dirtMap, gl_TexCoord[1].st);
 
 	// TODO: Blend textures with base color
	vec4 color = baseColor*texColor*dirtColor;
	
	// TODO: Set final fragment color
	gl_FragColor = color;

}

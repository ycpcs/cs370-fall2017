// CS370 - Fall 2016
// Lab11 - SimpleGLSL

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
#define DEFAULT_SHADER 0
#define USER_SHADER 1
#define X 0
#define Y 1
#define Z 2
GLchar* vertexFile = "simplevert.vs";
GLchar* fragmentFile = "simplefrag.fs";

// Shader objects
GLuint shaderProg;

// Global camera vectors
GLfloat eye[3] = { 1.0f,1.0f,1.0f };
GLfloat at[3] = { 0.0f,0.0f,0.0f };
GLfloat up[3] = { 0.0f,1.0f,0.0f };

// Global screen extents
GLint ww;
GLint hh;

// TODO: Global shader variables
GLuint timeParam;
GLfloat app_time = 0.0f;

int shader_flag = USER_SHADER;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void idlefunc();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Simple GLSL");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// TODO: Associate time uniform shader variable
	timeParam = glGetUniformLocation(shaderProg, "time");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set 3D projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLfloat xratio = 1.0f;
	GLfloat yratio = 1.0f;
	// Taller than wide so scale height
	if (ww <= hh)
	{
		yratio = (GLfloat)ww / (GLfloat)hh;
	}
	// Wider than tall so scale width
	else
	{
		xratio = (GLfloat)hh / (GLfloat)ww;
	}
	glOrtho(-3.0f*xratio, 3.0*xratio, -3.0f*yratio, 3.0f*yratio, -3.0f, 3.0f);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene without shadows
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Attach time uniform shader variable
	glUniform1f(timeParam, app_time);

	// Draw yellow cube
	glPushMatrix();
		glColor3f(1.0f,1.0f,0.0f);
		glutSolidCube(1.0);
	
		// Draw edges
		glColor3f(0.0f,0.0f,0.0f);
		glutWireCube(1.0);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles default shader
	if (key == ' ')
	{
		if (shader_flag == USER_SHADER)
		{
			// Use default shader
			glUseProgram(0);
			shader_flag = DEFAULT_SHADER;
		}
		else if (shader_flag == DEFAULT_SHADER)
		{
			// Use user shader
			glUseProgram(shaderProg);
			shader_flag = USER_SHADER;
		}
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0,0,w,h);

	// Store new extents
	ww = w;
	hh = h;
}

// Idle callback
void idlefunc()
{
	// Get time (in sec)
	app_time = glutGet(GLUT_ELAPSED_TIME) / 1000.0f;

	// Render scene
	glutPostRedisplay();
}

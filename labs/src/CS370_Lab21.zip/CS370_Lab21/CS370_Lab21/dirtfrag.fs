// TODO: Sampler variables

varying vec4 baseColor;

void main()
{  
	// TODO: Sample textures
 
 	// TODO: Blend textures with base color
	
	// TODO: Set final fragment color

}

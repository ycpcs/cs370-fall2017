// CS370 - Fall 2016
// Lab07 - SpinningCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

// TODO: Cube vertices
GLfloat cube[][3];

// Vertex colors
GLfloat colors[][3] = {{0.0f,0.0f,0.0f},{1.0f,0.0f,0.0f},{1.0f,0.0f,1.0f},
                       {0.0f,0.0f,1.0f},{0.0f,1.0f,0.0f},{1.0f,1.0f,0.0f},
                       {1.0f,1.0f,1.0f},{0.0f,1.0f,1.0f}};

// Global rotation values
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global screen dimensions
GLfloat ww,hh;

// Animation flag
GLint anim = false;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void colorcube();
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[]);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// TODO: Initialize the window with double buffering and RGB colors *and depth buffer*
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Spinning Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// TODO: Define callbacks *including reshape callback*
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// TODO: Enable depth test


	// Load and activate shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	glUseProgram(shaderProg);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// TODO: Reset background *and depth buffer*
	glClear(GL_COLOR_BUFFER_BIT);

	// TODO: Set projection matrix for anisotropic scaling
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Set modelview matrix with default camera
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Instance transformation to rotate cube

	// TODO: Draw cube

}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0, 0, w, h);

	// TODO: Store new extents

}

// Routine to draw cube
void colorcube()
{
	// TODO: Top face

	// TODO: Bottom face

	// TODO: Left face

	// TODO: Right face

	// TODO: Front face

	// TODO: Back face
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{

	// <space> toggles animation
	if (key == ' ')
	{
		anim = !anim;
	}
	// <esc> quits
	else if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	// Animation code
	if (anim)
	{
		theta += dtheta;
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}

		// Redraw screen
		glutPostRedisplay();
	}
}

// Routine to draw (outlined) quadrilateral face
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[])
{
	// Draw face
	glBegin(GL_POLYGON);
		glColor3fv(c1);
		glVertex3fv(v1);
		glColor3fv(c2);
		glVertex3fv(v2);
		glColor3fv(c3);
		glVertex3fv(v3);
		glColor3fv(c4);
		glVertex3fv(v4);
	glEnd();

	// Draw outline
	glColor3f(0.0f,0.0f,0.0f);
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();
}

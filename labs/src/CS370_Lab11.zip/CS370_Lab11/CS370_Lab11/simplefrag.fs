// TODO: Define globals

void main()
{
    // TODO: Set fragment color
}

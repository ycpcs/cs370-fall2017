// CS370
// Lab02 - ShadedHexagon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glut.h>
#endif

void display();
void render_Scene();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Shaded Hexagon");

	// Define callbacks
	glutDisplayFunc(display);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Set current color to red
	glColor3f(1.0f,0.0f,0.0f);

	// TODO: Draw hexagon and add colors

}
// CS370
// Lab01 - HelloOpenGL

#ifdef OSX
    #include <GLUT/glut.h>
#else
    #include <GL/glut.h>
#endif

void display();
void render_Scene();

int main(int argc, char *argv[])
{
	// TODO: Initialize GLUT
	return 0;
}

// Display callback
void display()
{
	// TODO: Setup display
}

// Scene render function
void render_Scene()
{
	// TODO: Draw graphics
}